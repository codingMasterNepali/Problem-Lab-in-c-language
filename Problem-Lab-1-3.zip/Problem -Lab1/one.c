#include<stdio.h>
int main(){

    int assignValue=7; // value assign to the variable 

    printf("The Assigned value is %d",assignValue);  // print the assigned value



    return 0;
}