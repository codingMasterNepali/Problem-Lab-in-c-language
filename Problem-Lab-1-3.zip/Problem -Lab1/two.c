#include<stdio.h>
int main(){
    int firstValue;
    int secondValue;
    int result=firstValue+secondValue;
    printf("Enter the first value:");
    scanf("%d",&firstValue);
     printf("Enter the second value:");
    scanf("%d",&secondValue);
   
    printf("The sum of the value is %d",result);


    return 0;
}