
#include<stdio.h>
int main(){

    for(int i=1;i<=10;i++){
        int counter;
        printf("Counter : %d\n",i);
    }

    return 0;
}