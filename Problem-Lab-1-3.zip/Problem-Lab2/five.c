#include<stdio.h>
#include<math.h>

int main(){
float num;
printf("Enter a floating number:\n");
scanf("%f",&num);

printf("The nearest integer number is(Rounded value): %f",round(num));   

    return 0;
}