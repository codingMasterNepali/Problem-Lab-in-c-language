#include<stdio.h>

int main(){

    int a,b;
    printf("Enter first number\n");
    scanf("%d",&a);
    printf("Enter second number:\n");
    scanf("%d",&b);

    printf("Addition: %d\n",a+b);
    printf("Subtration: %d\n",a-b);
    printf("Multiplication: %d\n",a*b);
    printf("Division: %d\n",a/b);
    printf("Remainder: %d",a%b);

    return 0;
}