#include<stdio.h>
#include<ctype.h>

int main(){

    char ch;
    printf("Enter a character: ");
    scanf("%c",&ch);

    if(isalpha(ch)){
        printf("%c is an alpahabet",ch);

    }
    else if(isdigit(ch)){
        printf("%c is a digit",ch);
    }
    else{
        printf("%c is neither alphabet nor a digit",ch);
    }


    return 0;
}