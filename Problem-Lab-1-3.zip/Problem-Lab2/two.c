#include<stdio.h>

int main(){

    int number;
    printf("Enter a number\n");
    scanf("%d",&number);

    if(number%2==0){
        printf("This is EVEN number");

    }
    else{
        printf("This is ODD number");
    }


    return 0;
}