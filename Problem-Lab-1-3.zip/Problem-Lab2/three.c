#include<stdio.h>

int main(){

    int firstNum,secondNum,thirdNum,sum;
    printf("Enter three number:\n");
    scanf("%d%d%d",&firstNum,&secondNum,&thirdNum);
    sum= firstNum+secondNum+thirdNum; // length = 3;
    float avg=sum/3.0;

    printf("The average value of three number is: %.2f",avg);

    return 0;
}