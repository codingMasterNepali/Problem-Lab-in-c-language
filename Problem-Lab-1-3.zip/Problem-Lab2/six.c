#include<stdio.h>
#include<ctype.h>

int main(){

    int a,b;
    printf("Enter first number:\n");
    scanf("%d",&a);
    printf("Enter second number:\n");
    scanf("%d",&b);

    //SWAP
    a =a^b;
    b=a^b;
    a=a^b;

    //values After swapping 
    printf("After Swapping: a is %d b is %d\n",a,b);


    return 0;
}