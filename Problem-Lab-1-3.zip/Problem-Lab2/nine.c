#include <stdio.h>

void printBinary(int num) {
    unsigned int mask = 1 << (sizeof(int) * 8 - 1);  // Mask for the most significant bit
    while (mask) {
        if (num & mask)
            printf("1");
        else
            printf("0");
        mask >>= 1;
    }
    printf("\n");
}

int main() {
    int num;
    
    printf("Enter an integer: ");
    scanf("%d", &num);
    
    printf("Binary equivalent: ");
    printBinary(num);

    return 0;
}
