#include <stdio.h>
#include<math.h>
int main(){

float num1, num2,epsilon;

printf("Enter first floating point number:\n");
scanf("%f",&num1);
printf("Enter second floating point number:\n");
scanf("%f",&num1);
printf("Enter epsilon:\n");
scanf("%f",&epsilon);

if(fabs(num1-num2)<epsilon){
    printf("The number are equal up to the given precesion");

}
else{
     printf("The number are not equal up to the given precesion");
}
    return 0;
}
