#include <stdio.h>
int main()
{
       int a,b;
       printf("Enter two positive number:\n");
       scanf("%d%d",&a,&b);
       while(a!=b){
        if(a>b){
            a=a-b;
        }
        else{
            b=b-a;

        }
       }
       printf("The greterst common divisor is %d",a);


    return 0;
}