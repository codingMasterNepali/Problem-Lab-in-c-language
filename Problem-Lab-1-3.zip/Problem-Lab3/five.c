#include <stdio.h>
int main()
{
    //  factorial of 5 = 1*2*3*4*5= 120

    int num, factorial=1;
    printf("Enter a number:\n");
    scanf("%d", &num);
    if (num < 0)
    {
        printf("The number less than zero(0) doesn't exit!");
        
    }
    else
        {
            for (int i = 1; i <= num; i++)
            {
                factorial = factorial * i;
            }
            printf("The factorial of %d is %llu", num, factorial);
        }

    return 0;
}