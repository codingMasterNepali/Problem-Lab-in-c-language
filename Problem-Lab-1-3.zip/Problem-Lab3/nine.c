#include <stdio.h>
int main()
{
    int num, original, remainder, result = 0;
    printf("Enter a three digit integer:\n");
    scanf("%d", &num);
    original = num;
    while (original != 0)
    {
        remainder = original % 10;
        result = result + remainder * remainder * remainder;
        original = original / 10;
    }
    if (result == num)
    {
        printf("%d is a Armstrong number", num);
    }
    else
    {
        printf("%d is not a Armstrong number", num);
    }

    return 0;
}