#include <stdio.h>
int main()
{
        // fabonacci series->> 0,1,1,2,3 
        int n;
        int ft=0;
        int st=1;
        int nextTerm=0;

        printf("Enter the terms of number:\n");
        scanf("%d",&n);

        printf("Fibonacci serires of %d,%d ",ft,st);
        for(int i=3;i<=n;i++){
            nextTerm=ft+st;
            printf(",%d",nextTerm);
            ft=st;
            st=nextTerm;

        }





    return 0;
}