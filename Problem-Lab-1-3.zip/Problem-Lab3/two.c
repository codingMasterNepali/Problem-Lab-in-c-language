#include <stdio.h>
int main()
{
    int num, sum = 0, remainder;
    printf("Enter a number\n");
    scanf("%d", &num); // example take 12 from user = 1+2=3

    while (num != 0)
    {
        remainder = num % 10;   // 12 taken from user remainder =2;
        sum = sum + remainder;  // 0+2=2
        num = num / 10;  // 1 
    }
    printf("The sum of the digits is %d", sum);

    return 0;
}