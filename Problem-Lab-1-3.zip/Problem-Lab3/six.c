#include <stdio.h>
int main(){

        // 121 == palindrome 
        // 342== not palindrome
    int num,original,reversed=0,remainder;

    printf("Enter the number:\n");
    scanf("%d",&num);

    original=num;
    while(num!=0){
        remainder=num%10;
        reversed=reversed*10+remainder;
        num=num/10;
    }

    if(original==reversed){
        printf("%d is a palindrome number",original);
    }
    else{
        printf("%d is not a palindrome number",original);
    }

    return 0;
}