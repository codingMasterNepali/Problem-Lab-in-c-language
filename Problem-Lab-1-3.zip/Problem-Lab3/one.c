#include <stdio.h>
int main()
{
    int fNum, sNum, tNum;

    printf("Enter first number:\n");
    scanf("%d", &fNum);
    printf("Enter second number:\n");
    scanf("%d", &sNum);
    printf("Enter third number:\n");
    scanf("%d", &tNum);

    if (fNum >= sNum && fNum >= tNum)
    {
        printf("Largest numer is %d", fNum);
    }
    else if(sNum>=fNum && sNum>=tNum){
        printf("Largest number is %d",sNum);
    }
    else{
        printf("Largest number is %d",tNum);
    }

    return 0;
}